# Dinobot
Automation of google chrome's using Python
